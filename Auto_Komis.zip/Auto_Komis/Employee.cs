﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auto_Komis
{
    public class Employee
    {
        public string UserLogin { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int PositionID { get; set; }
        public int DiscountLevel { get; set; }
    }
}
